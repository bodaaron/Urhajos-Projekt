﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace BA_Urhajos
{
    class Urbazis
    {
        Random r = new Random();
        static public UrbazisElem[,] palya = new UrbazisElem[22, 22];
        public int[,] felfedezett_koordinatak = new int[22, 22];
        public List<(int, int)> felfedezett_kannak = new List<(int, int)>();
        public List<(int, int)> felfedezett_csokik = new List<(int, int)>();
        public bool kapu_felfedezve = false;


        public void generalas()
        {
            ground_generalas();
            kanna_generalas();
            kapu_generalas();
            akadaly_generalas();
            urhajos_generalas();
            robot_generalas();
            csoki_generalas();

            felfedez();
        }

        public void szimulal()
        {
            Thread.Sleep(1000);
            Console.ResetColor();
            Console.Clear();
            tabla_kiiratas();
            Console.ResetColor();
            harcol_e();
            if(u.eletero <= 0)
            {
                Console.ResetColor();
                Console.Clear();
                Console.WriteLine("Az űrhajós meghalt.");
                Console.ReadLine();
                Environment.Exit(0);
            }
            Console.WriteLine($"Űrhajós életereje:{u.eletero}");
            Console.WriteLine($"Begyüjtött kannák:{u.felszedett_kannak}/3");
            Console.WriteLine($"Csokik {Csoki.db}");
            Console.WriteLine($"Robotok {Robot.db}");
            urhajos_lep();
        }

        public void ground_generalas()
        {
            for (var i = 0; i < 484; i++) 
            {
                int sor = r.Next(0, 22);
                int oszlop = r.Next(0, 22);
                while (van_e_ott_ertek_ground(sor, oszlop))
                {
                    sor = r.Next(0, 22);
                    oszlop = r.Next(0, 22);
                }
                palya[sor, oszlop] = new Ground(sor, oszlop);
            }
        }

        public void kanna_generalas()
        {
            for (var i = 0; i < 3; i++)
            {
                int sor = r.Next(0, 22);
                int oszlop = r.Next(0, 22);
                palya[sor, oszlop] = new Kanna(sor, oszlop);
            }
        }

        public Kapu k;
        public void kapu_generalas()
        {
            int sor = kapu_hatar();
            int oszlop = r.Next(0, 22);
            while (van_e_ott_ertek(sor, oszlop))
            {
                sor = kapu_hatar();
                oszlop = r.Next(0,22);
            }
            k = new Kapu(sor, oszlop);
            palya[sor, oszlop] = k;
        }

        public void akadaly_generalas()
        {
            for(var i = 0;i < 10; i++)
            {
                int sor = r.Next(0, 22);
                int oszlop = r.Next(0, 22);
                while (van_e_ott_ertek(sor, oszlop))
                {
                    sor = r.Next(0,22);
                    oszlop = r.Next(0,22);
                }
                palya[sor, oszlop] = new Akadaly(sor, oszlop);
            }
        }

        public void robot_generalas()
        {
            for (var i = 0; i < 4; i++)
            {
                int sor = r.Next(0, 22);
                int oszlop = r.Next(0, 22);
                while (van_e_ott_ertek(sor, oszlop))
                {
                    sor = r.Next(0, 22);
                    oszlop = r.Next(0, 22);
                }
                palya[sor, oszlop] = new Robot(sor, oszlop);
            }
        }

        public void csoki_generalas()
        {
            for (var i = 0; i < 4; i++)
            {
                int sor = r.Next(0, 22);
                int oszlop = r.Next(0, 22);
                while (van_e_ott_ertek(sor, oszlop))
                {
                    sor = r.Next(0, 22);
                    oszlop = r.Next(0, 22);
                }
                palya[sor, oszlop] = new Csoki(sor, oszlop);
            }
        }

        public void csoki_feltoltes()
        {
            int sor = r.Next(0, 22);
            int oszlop = r.Next(0, 22);
            while (van_e_ott_ertek(sor, oszlop))
            { 
                {
                    sor = r.Next(0, 22);
                    oszlop = r.Next(0, 22);
                }
                palya[sor, oszlop] = new Csoki(sor, oszlop);
            }
        }

        public int kapu_hatar()
        {
            int sor = r.Next(0, 2);
            return sor == 0 ? 0 : 21;
        }

        public Urhajos u;
        public void urhajos_generalas()
        {
            int sor = r.Next(0, 22);
            int oszlop = r.Next(0, 22);
            u = new Urhajos(sor, oszlop);
            palya[sor, oszlop] = u;
        }

        public void szin(int sor, int oszlop)
        {
            UrbazisElem elem = palya[sor, oszlop];

            if (elem is Ground)
            {
                Console.BackgroundColor = ConsoleColor.Green;
            }
            else if (elem is Urhajos)
            {
                Console.BackgroundColor = ConsoleColor.White;
            }
            else if (elem is Kanna)
            {
                Console.BackgroundColor = ConsoleColor.Red;
            }
            else if(elem is Kapu)
            {
                Console.BackgroundColor = ConsoleColor.DarkMagenta;
            }
            else if(elem is Akadaly)
            {
                Console.BackgroundColor = ConsoleColor.Yellow;
            }
            else if (elem is Csoki)
            {
                Console.BackgroundColor = ConsoleColor.DarkYellow;
            }
            else if (elem is Robot)
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
            }
        }

        public void tabla_kiiratas()
        {
            for (int i = 0; i < palya.GetLength(0); i++)
            {
                for (int j = 0; j < palya.GetLength(1); j++)
                {
                    if (felfedezett(i, j) || felfedezett_koordinatak[i,j] == 1)
                    {
                        szin(i, j);
                        Console.Write(palya[i, j]);
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write(palya[i, j]);
                    }
                }
                Console.WriteLine();
            }
        }

        public int JoE(int a)
        {
            while (a < 0)
            {
                a++;
            }
            while (a > 22)
            {
                a--;
            }
            return a;
        }

        public bool felfedezett(int sor, int oszlop)
        {
            int balx = u.palyan_helye_sor - 1;
            int baly = u.palyan_helye_oszlop - 1;

            for (int i = JoE(balx); i < JoE(balx + 1 * 2 + 1); i++)
            {
                for (int j = JoE(baly); j < JoE(baly + 1 * 2 + 1); j++)
                {
                    if(palya[i,j] == palya[sor, oszlop])
                    {
                        felfedezett_koordinatak[i, j] = 1;
                        if (palya[i,j] is Kanna && !van_e_benne_kanna(i,j))
                        {
                            felfedezett_kannak.Add((i, j));
                        }
                        if (palya[i, j] is Csoki && !van_e_benne_csoki(i, j))
                        {
                            felfedezett_csokik.Add((i, j));
                        }
                        if (palya[i,j] is Kapu)
                        {
                            kapu_felfedezve = true;
                        }
                        return true;
                    }
                }
            }
            return false;
        }

        public void harcol_e()
        {
            int balx = u.palyan_helye_sor - 1;
            int baly = u.palyan_helye_oszlop - 1;

            for (int i = JoE(balx); i < JoE(balx + 1 * 2 + 1); i++)
            {
                for (int j = JoE(baly); j < JoE(baly + 1 * 2 + 1); j++)
                {
                    if (palya[i, j] is Robot)
                    {
                        Robot ellenseg = (Robot)palya[i, j];
                        u.harcol(ellenseg);
                    }
                }
            }
        }
        public int felfedezendo_sor;
        public int felfedezendo_oszlop;
        public void felfedez()
        {
            felfedezendo_sor = r.Next(0, 22);
            felfedezendo_oszlop = r.Next(0, 22);
            while (felfedezett(felfedezendo_sor, felfedezendo_oszlop))
            {
                felfedezendo_sor = r.Next(0, 22);
                felfedezendo_oszlop = r.Next(0, 22);
            }
        }

        public bool felfedezett_e(int sor,int oszlop)
        {
            if (felfedezett_koordinatak[sor,oszlop] == 1)
            {
                return true;
            }
            return false;
        }

        public bool van_e_benne_kanna(int sor,int oszlop)
        {
            for (int i = 0; i < felfedezett_kannak.Count; i++)
            {
                if (felfedezett_kannak[i] == (sor, oszlop))
                {
                    return true;
                }
            }
            return false;
        }

        public bool van_e_benne_csoki(int sor, int oszlop)
        {
            for (int i = 0; i < felfedezett_csokik.Count; i++)
            {
                if (felfedezett_csokik[i] == (sor, oszlop))
                {
                    return true;
                }
            }
            return false;
        }

        public void felfele()
        {
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = new Ground(u.palyan_helye_sor, u.palyan_helye_oszlop);
            u.palyan_helye_sor--;
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = u;
            szimulal();
        }

        public void lefele()
        {
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = new Ground(u.palyan_helye_sor, u.palyan_helye_oszlop);
            u.palyan_helye_sor++;
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = u;
            szimulal();
        }

        public void balra() 
        {
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = new Ground(u.palyan_helye_sor, u.palyan_helye_oszlop);
            u.palyan_helye_oszlop--;
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = u;
            szimulal();
        }

        public void jobbra()
        {
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = new Ground(u.palyan_helye_sor, u.palyan_helye_oszlop);
            u.palyan_helye_oszlop++;
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = u;
            szimulal();
        }

        public void kanna_felszedve()
        {
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = new Ground(u.palyan_helye_sor, u.palyan_helye_oszlop);
            felfedezett_kannak.RemoveAt(0);
            u.felszedett_kannak++;
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = u;
            szimulal();
        }

        public void csoki_felszedve()
        {
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = new Ground(u.palyan_helye_sor, u.palyan_helye_oszlop);
            felfedezett_csokik.RemoveAt(0);
            u.eletero += 50;
            Csoki.db--;
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = u;
            csoki_feltoltes();
            szimulal();
        }

        public void jatek_vege()
        {
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = new Ground(u.palyan_helye_sor, u.palyan_helye_oszlop);
            palya[u.palyan_helye_sor, u.palyan_helye_oszlop] = u;
            Console.Clear();
            Console.WriteLine("Az űrhajós összeszedte az összes kannát és kijutott a kapun");
            Console.ReadLine();
            Environment.Exit(0);
        }
        public void urhajos_lep()
        {
            if (felfedezett_csokik.Count != 0 && u.eletero <= 50)
            {
                while (u.palyan_helye_sor != felfedezett_csokik[0].Item1 || u.palyan_helye_oszlop != felfedezett_csokik[0].Item2 || u.palyan_helye_sor == felfedezett_csokik[0].Item1 && u.palyan_helye_oszlop == felfedezett_csokik[0].Item2)
                {
                    if (u.palyan_helye_sor > felfedezett_csokik[0].Item1 && !lephet_e_oda_csokihoz_megy(u.palyan_helye_sor - 1, u.palyan_helye_oszlop))
                    {
                        felfele();
                    }
                    else if (u.palyan_helye_sor < felfedezett_csokik[0].Item1 && !lephet_e_oda_csokihoz_megy(u.palyan_helye_sor + 1, u.palyan_helye_oszlop))
                    {
                        lefele();
                    }
                    else if (u.palyan_helye_oszlop > felfedezett_csokik[0].Item2 && !lephet_e_oda_csokihoz_megy(u.palyan_helye_sor, u.palyan_helye_oszlop - 1))
                    {
                        balra();
                    }
                    else if (u.palyan_helye_oszlop < felfedezett_csokik[0].Item2 && !lephet_e_oda_csokihoz_megy(u.palyan_helye_sor, u.palyan_helye_oszlop + 1))
                    {
                        jobbra();
                    }
                    else if (u.palyan_helye_sor == felfedezett_csokik[0].Item1 && u.palyan_helye_oszlop == felfedezett_csokik[0].Item2)
                    {
                        csoki_felszedve();
                    }
                }
            }
            else if (felfedezett_kannak.Count != 0)
            {
                while (u.palyan_helye_sor != felfedezett_kannak[0].Item1 || u.palyan_helye_oszlop != felfedezett_kannak[0].Item2 || u.palyan_helye_sor == felfedezett_kannak[0].Item1 && u.palyan_helye_oszlop == felfedezett_kannak[0].Item2)
                {
                    if (u.palyan_helye_sor > felfedezett_kannak[0].Item1 && !lephet_e_oda(u.palyan_helye_sor - 1, u.palyan_helye_oszlop))
                    {
                        felfele();
                    }
                    else if (u.palyan_helye_sor < felfedezett_kannak[0].Item1 && !lephet_e_oda(u.palyan_helye_sor + 1, u.palyan_helye_oszlop))
                    {
                        lefele();
                    }
                    else if (u.palyan_helye_oszlop > felfedezett_kannak[0].Item2 && !lephet_e_oda(u.palyan_helye_sor, u.palyan_helye_oszlop - 1))
                    {
                        balra();
                    }
                    else if (u.palyan_helye_oszlop < felfedezett_kannak[0].Item2 && !lephet_e_oda(u.palyan_helye_sor, u.palyan_helye_oszlop + 1))
                    {
                        jobbra();
                    }
                    else if (u.palyan_helye_sor == felfedezett_kannak[0].Item1 && u.palyan_helye_oszlop == felfedezett_kannak[0].Item2)
                    {
                        kanna_felszedve();
                    }
                }
            }
            else if (kapu_felfedezve == true && u.felszedett_kannak == 3)
            {
                while (u.palyan_helye_sor != k.palyan_helye_sor || u.palyan_helye_oszlop != k.palyan_helye_oszlop || u.palyan_helye_sor == k.palyan_helye_sor && u.palyan_helye_oszlop == k.palyan_helye_oszlop)
                {
                    if (u.palyan_helye_sor > k.palyan_helye_sor && !lephet_e_oda_kapuhoz_megy(u.palyan_helye_sor - 1, u.palyan_helye_oszlop))
                    {
                        felfele();
                    }
                    else if (u.palyan_helye_sor < k.palyan_helye_sor && !lephet_e_oda_kapuhoz_megy(u.palyan_helye_sor + 1, u.palyan_helye_oszlop))
                    {
                        lefele();
                    }
                    else if (u.palyan_helye_oszlop > k.palyan_helye_oszlop && !lephet_e_oda_kapuhoz_megy(u.palyan_helye_sor, u.palyan_helye_oszlop - 1))
                    {
                        balra();
                    }
                    else if (u.palyan_helye_oszlop < k.palyan_helye_oszlop && !lephet_e_oda_kapuhoz_megy(u.palyan_helye_sor, u.palyan_helye_oszlop + 1))
                    {
                        jobbra();
                    }
                    else if (u.palyan_helye_sor == k.palyan_helye_sor && u.palyan_helye_oszlop == k.palyan_helye_oszlop)
                    {
                        jatek_vege();
                    }
                }
            }
            else
            {
                while (felfedezett_kannak.Count == 0)
                {
                    while (u.palyan_helye_sor != felfedezendo_sor || u.palyan_helye_oszlop != felfedezendo_oszlop || u.palyan_helye_sor == felfedezendo_sor && u.palyan_helye_oszlop == felfedezendo_oszlop)
                    {
                        if (u.palyan_helye_sor > felfedezendo_sor && !lephet_e_oda(u.palyan_helye_sor - 1, u.palyan_helye_oszlop))
                        {
                            felfele();
                        }
                        else if (u.palyan_helye_sor < felfedezendo_sor && !lephet_e_oda(u.palyan_helye_sor + 1, u.palyan_helye_oszlop))
                        {
                            lefele();
                        }
                        else if (u.palyan_helye_oszlop > felfedezendo_oszlop && !lephet_e_oda(u.palyan_helye_sor, u.palyan_helye_oszlop - 1))
                        {
                            balra();
                        }
                        else if (u.palyan_helye_oszlop < felfedezendo_oszlop && !lephet_e_oda(u.palyan_helye_sor, u.palyan_helye_oszlop + 1))
                        {
                            jobbra();
                        }
                        if (u.palyan_helye_sor == felfedezendo_sor || u.palyan_helye_oszlop == felfedezendo_oszlop)
                        {
                            felfedez();
                        }
                    }
                }
            }
        }

        public bool van_e_ott_ertek_ground(int sor, int oszlop)
        {
            if (palya[sor, oszlop] is Ground)
            {
                return true;
            }
            return false;
        }

        public bool van_e_ott_ertek(int sor, int oszlop)
        {
            if (palya[sor, oszlop] is Kanna || palya[sor,oszlop] is Akadaly || palya[sor,oszlop] is Kapu || palya[sor, oszlop] is Csoki || palya[sor,oszlop] is Robot || palya[sor,oszlop] is Urhajos)
            {
                return true;
            }
            return false;
        }

        public bool lephet_e_oda(int sor, int oszlop)
        {
            if (palya[sor, oszlop] is Akadaly || palya[sor, oszlop] is Kapu || palya[sor,oszlop] is Csoki)
            {
                return true;
            }
            return false;
        }

        public bool lephet_e_oda_csokihoz_megy(int sor, int oszlop)
        {
            if (palya[sor, oszlop] is Akadaly || palya[sor, oszlop] is Kapu)
            {
                return true;
            }
            return false;
        }


        public bool lephet_e_oda_kapuhoz_megy(int sor, int oszlop)
        {
            if (palya[sor, oszlop] is Akadaly || palya[sor,oszlop] is Csoki)
            {
                return true;
            }
            return false;
        }

    }
}
