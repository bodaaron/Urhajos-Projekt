﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BA_Urhajos
{
    class Robot : UrbazisElem
    {
        Random r = new Random();
        public int sebzes, eletero = 100;
        public static int db = 0;
        public Robot(int palyan_helye_sor, int palyan_helye_oszlop) : base(palyan_helye_sor, palyan_helye_oszlop)
        {
            sebzes = r.Next(10, 18);
            db++;
        }
        public override string ToString()
        {
            return "  ";
        }
    }
}
