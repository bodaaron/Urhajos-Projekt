﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BA_Urhajos
{
    class Csoki : UrbazisElem
    {
        public static int db;
        public Csoki(int palyan_helye_sor, int palyan_helye_oszlop) : base(palyan_helye_sor, palyan_helye_oszlop)
        {
            db++;
        }

        public override string ToString()
        {
            return "  ";
        }
    }
}
