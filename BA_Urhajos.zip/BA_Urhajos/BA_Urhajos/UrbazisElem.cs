﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BA_Urhajos
{
    abstract class UrbazisElem
    {
        public int palyan_helye_sor, palyan_helye_oszlop;
        protected UrbazisElem(int palyan_helye_sor, int palyan_helye_oszlop)
        {
            this.palyan_helye_sor = palyan_helye_sor;
            this.palyan_helye_oszlop = palyan_helye_oszlop;
        }
    }
}
