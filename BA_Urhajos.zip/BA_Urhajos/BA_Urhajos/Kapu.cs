﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BA_Urhajos
{
    internal class Kapu : UrbazisElem
    {
        public Kapu(int palyan_helye_sor, int palyan_helye_oszlop) : base(palyan_helye_sor, palyan_helye_oszlop)
        {
        }

        public override string ToString()
        {
            return "  ";
        }
    }
}
