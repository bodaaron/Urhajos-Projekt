﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BA_Urhajos
{
    class Program
    {
        static void Main(string[] args)
        {
            Urbazis urbazis = new Urbazis();
            urbazis.generalas();
            urbazis.szimulal();
            Console.ReadLine();
        }
    }
}
