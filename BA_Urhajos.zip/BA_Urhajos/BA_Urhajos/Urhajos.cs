﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BA_Urhajos
{
    class Urhajos : UrbazisElem
    {
        Random r = new Random();
        public int sebzes, eletero = 100;
        public int felszedett_kannak = 0;
        public Urhajos(int palyan_helye_sor, int palyan_helye_oszlop) : base(palyan_helye_sor, palyan_helye_oszlop)
        {
            sebzes = r.Next(21, 34);
        }

        public void harcol(Robot ellenseg)
        {
            Console.WriteLine("Az űrhajós robottal találkozott és most harcol vele");
            int i = 1;
            while(ellenseg.eletero > 0 && eletero > 0)
            {
                if (i % 2 != 0)
                {
                    ellenseg.eletero = ellenseg.eletero - sebzes;
                    Console.WriteLine($"Az űrhajós sebzi a Robotot, a Robot életereje: {ellenseg.eletero}");
                }
                else if (i % 2 == 0)
                { 
                    eletero = eletero - ellenseg.sebzes;
                    Console.WriteLine($"A robot sebzi az Űrhajóst, az Űrhajós életereje: {eletero}");
                }
                i++;
                Thread.Sleep(5000);
            }
            if(ellenseg.eletero <= 0)
            {
                Console.WriteLine($"Az űrhajós legyőzte a robotot de {eletero} életereje maradt");
                Thread.Sleep(3000);
                Console.Clear();
                Urbazis.palya[ellenseg.palyan_helye_sor, ellenseg.palyan_helye_oszlop] = new Ground(ellenseg.palyan_helye_sor, ellenseg.palyan_helye_oszlop);
                Robot.db--;
            }
        }
        
        public override string ToString()
        {
            return "  ";
        }
    }
}
